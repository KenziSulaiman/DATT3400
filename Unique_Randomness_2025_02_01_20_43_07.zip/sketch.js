let colors = [];
let numColors = 100;
let bgColor = 255;
let currentFeatures = [];
let featureChangeSpeed = 0.05;

function setup() {
  createCanvas(800, 600);
  generateRandomColors(numColors);
  initializeFeatures();
  frameRate(30);
}

function draw() {
  background(bgColor);
  updateFeatures();
  displayKirbies();
}

function initializeFeatures() {
  for (let i = 0; i < numColors; i++) {
    currentFeatures.push({
      eyeW: random(10, 16),
      eyeH: random(12, 18),
      mouthScale: random(0.5, 1.5),
      hairType: random() < 0.3 ? 'curly' : 'straight',
      hairSize: random(15, 25),
      eyeOffset: random(-2, 2),
      targetEyeW: random(10, 16),
      targetEyeH: random(12, 18),
      targetMouth: random(0.5, 1.5)
    });
  }
}

function updateFeatures() {
  for (let i = 0; i < currentFeatures.length; i++) {
    currentFeatures[i].eyeW = lerp(currentFeatures[i].eyeW, currentFeatures[i].targetEyeW, featureChangeSpeed);
    currentFeatures[i].eyeH = lerp(currentFeatures[i].eyeH, currentFeatures[i].targetEyeH, featureChangeSpeed);
    currentFeatures[i].mouthScale = lerp(currentFeatures[i].mouthScale, currentFeatures[i].targetMouth, featureChangeSpeed);
    
    if (random() < 0.02) {
      currentFeatures[i].targetEyeW = random(10, 16);
      currentFeatures[i].targetEyeH = random(12, 18);
      currentFeatures[i].targetMouth = random(0.5, 1.5);
    }
  }
}

function generateRandomColors(count) {
  for (let i = 0; i < count; i++) {
    colors.push({
      r: floor(random(256)),
      g: floor(random(256)),
      b: floor(random(256))
    });
  }
}

function displayKirbies() {
  let margin = 50;
  let cols = 10;
  let kirbySize = (width - margin * 2) / cols;

  for (let i = 0; i < colors.length; i++) {
    let col = i % cols;
    let row = floor(i / cols);
    let x = margin + col * kirbySize;
    let y = margin + row * kirbySize;
    
    drawKirby(x, y, kirbySize, colors[i], currentFeatures[i]);
  }
}

function drawKirby(x, y, size, color, features) {
  fill(color.r, color.g, color.b);
  ellipse(x, y, size, size);

  let eyeSpacing = 15 + features.eyeOffset;
  fill(255);
  ellipse(x - eyeSpacing, y - 12, features.eyeW, features.eyeH);
  ellipse(x + eyeSpacing, y - 12, features.eyeW, features.eyeH);
  
  fill(0);
  ellipse(x - eyeSpacing, y - 12, 6, 8);
  ellipse(x + eyeSpacing, y - 12, 6, 8);

  fill(173, 216, 230);
  ellipse(x - eyeSpacing - 2, y - 15, 5, 5);
  ellipse(x + eyeSpacing - 2, y - 15, 5, 5);

  let hairColor = [color.r * 0.8, color.g * 0.8, color.b * 0.8];
  fill(hairColor);
  if (features.hairType === 'curly') {
    drawCurlyHair(x, y - 25, features.hairSize);
  } else {
    drawStraightHair(x, y - 25, features.hairSize);
  }

  fill(255, 182, 193);
  ellipse(x - 30, y + 10, 15, 15);
  ellipse(x + 30, y + 10, 15, 15);

  noFill();
  stroke(0);
  strokeWeight(2);
  let mouthWidth = 20 * features.mouthScale;
  let mouthHeight = 15 * features.mouthScale;
  arc(x, y + 15, mouthWidth, mouthHeight, 0, PI);

  noStroke();
  fill(200, 100, 150);
  ellipse(x - 40, y + 10, 25, 10);
  ellipse(x + 40, y + 10, 25, 10);

  fill(150, 100, 200);
  ellipse(x - 20, y + 35, 25, 10);
  ellipse(x + 20, y + 35, 25, 10);
}

function drawCurlyHair(x, y, size) {
  beginShape();
  for (let i = 0; i < 5; i++) {
    let angle = map(i, 0, 5, 0, TWO_PI);
    let curlX = x + cos(angle) * size * 0.6;
    let curlY = y + sin(angle) * size * 0.4;
    ellipse(curlX, curlY, size * 0.4, size * 0.6);
  }
  endShape(CLOSE);
}

function drawStraightHair(x, y, size) {
  triangle(
    x - size/2, y,
    x + size/2, y,
    x, y - size
  );
  for (let i = 0; i < 3; i++) {
    let offset = map(i, 0, 3, -size/2, size/2);
    line(x + offset, y - size/2, x + offset * 0.8, y - size);
  }
}

function keyPressed() {
  if (key === 'S') saveColorsToCSV();
  if (key === ' ') bgColor = bgColor === 255 ? 0 : 255;
}

function saveColorsToCSV() {
  let csv = "Red,Green,Blue\n";
  colors.forEach(c => csv += `${c.r},${c.g},${c.b}\n`);
  saveStrings([csv], 'colors.csv');
}